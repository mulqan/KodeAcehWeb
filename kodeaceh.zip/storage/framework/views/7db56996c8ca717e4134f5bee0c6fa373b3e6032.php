<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.navbar-alt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 d-flex justify-content-center order-lg-1 mb-5">
            <div class="event-logo">
              <img class="img-fluid" src="<?php echo e(asset('logo/'.$data->image)); ?>" alt="Logo" />
            </div>
          </div>
          <div class="col-lg-9 order-lg-0">
            <h1 class="display-4 m-0"><?php echo e($data->name); ?></h1>
            <p class="lead"><?php echo e($data->description); ?></p>
            <div class="row">
              <div class="col-md-6">
                <ul class="fa-ul ml-4">
                  <li><i class="fa-li fa fa-user fa-lg"></i><b>Pemateri</b><br><?php echo e($data->tutor); ?></li>
                  <li><i class="fa-li fa fa-calendar-o fa-lg"></i><b>Waktu</b><br><?php echo e($data->date); ?></li>
                </ul>
              </div>
              <div class="col-md-6">
                <ul class="fa-ul ml-4">
                  <li><i class="fa-li fa fa-map-marker fa-lg"></i><b>Tempat</b><br><?php echo e($data->place); ?></li>
                  <li><i class="fa-li fa fa-ban fa-lg"></i><b>Batas Registrasi</b><br><?php echo e($data->deadline); ?></li>
                </ul>
              </div>
            </div>
            <a href="<?php echo e($data->registration_link); ?>" class="btn text-white custom-<?php echo e($data->color); ?> py-2 px-3 <?php echo e($data->registration_link ? '' : 'disabled'); ?>" target="_blank">
              <i class="fa fa-paper-plane" aria-hidden="true"></i> <?php echo e($data->registration_link ? 'Registrasi' : 'Belum Tersedia'); ?>

            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="container my-4">
      <div class="row">
        <div class="col-md-6 mb-4 mb-md-0 order-md-1">
          <div class="card">
            <div class="card-body">
              <p class="font-primary h3 mb-4">Prasyarat:</p>
              <?php echo $data->requirement; ?>

            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <p class="font-primary h3 mb-4">Materi:</p>
              <?php echo $data->content; ?>

            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kodeaceh\resources\views/event.blade.php ENDPATH**/ ?>