<div class="jumbotron jumbotron-fluid bg-dark">
  <div class="container">
    <div class="d-flex flex-column align-items-center justify-content-center">
      <p class="text-light m-0">Komunitas Developer Aceh - All right reserved</p>
      <div class="">
        <a href="https://instagram.com/kode_aceh" class="text-light text-decoration-none mx-3" target="_blank">
          <i class="fa fa-instagram mr-1" aria-hidden="true"></i>
          kode_aceh
        </a>
        <a href="https://t.me/kodeaceh" class="text-light text-decoration-none mx-3" target="_blank">
          <i class="fa fa-telegram mr-1" aria-hidden="true"></i>
          t.me/kodeaceh
        </a>
        <a href="mailto:kodeaceh.comunity@gmail.com" class="text-light text-decoration-none mx-3" target="_blank">
          <i class="fa fa-envelope mr-1" aria-hidden="true"></i>
          kodeaceh.comunity@gmail.com
        </a>
      </div>
    </div>
  </div>
</div>
