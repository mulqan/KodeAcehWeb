document.cookie = 'SameSite=None; Secure';

require('./bootstrap');
require('./main');
